$(document).ready(function() {


    
    function validatePassword(){
      const password=document.getElementById('pass').value;
      const passwordError=document.getElementById('passwordError')
      if(password===""){
          passwordError.textContent="Password is required"
          return false
      }else{
          passwordError.textContent=""
          return true 
      }
    }
    
    
    function validateEmail(){
      var email=document.getElementById('name').value;
      var emailError=document.getElementById('emailError')
      const match= /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    
      if(email===""){
          emailError.textContent="Email is required"
          return false
      }else if(!match.test(email)){
          emailError.textContent="Email is invalid"
          return false
      }
      else{
          emailError.textContent=""
          return true 
      }
    }
    
    
    function enableSubmit(){
        const passwordValid=validatePassword()
        const emailValid=validateEmail()
      const submitButton=document.getElementById('submit')
      if( passwordValid && emailValid){
        submitButton.disabled=false;
    } else {
        submitButton.disabled=true;
    }
    }
    
    
    $('#name , #pass ').on('keyup',function(){
        enableSubmit()
    })
    
    
    })
    
    
    
    document.getElementById('signup').on('click',function(event){
        event.preventDefault()
        // var FormData={
        //     name: document.getElementById('name').value,
        //     password: document.getElementById('password').value,
        //     email: document.getElementById('email').value
        // }
        })
    