$(document).ready(function() {

    function validateName(){
    var name=document.getElementById('name').value;
    var nameError=document.getElementById('nameError')
    if(name===""){
        nameError.textContent="Name is required"
        return false
    }else{
        nameError.textContent=""
        return true 
    }
    }

    function validatePassword(){
      const password=document.getElementById('pass').value;
      const passwordError=document.getElementById('passwordError')
      const passNumber= /[1-9]/.test(password);
      const passUpperr= /[A-Z]/.test(password);
      const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

      if(password===""){
          passwordError.textContent="Password is required"
          return false
      }else if(!passNumber){
        passwordError.textContent="Password must contain at least one number"
        return false

      }
      else if(!passNumber){
        passwordError.textContent="Password must contain at least one number"
        return false

      }
      else if(!passUpperr){
        passwordError.textContent="Password must contain at least one upper letter"
        return false

      
      }else if(!hasSpecialChar){
        passwordError.textContent="Password must contain at least one special character"
        return false
      }else if ((password.length)<5){
        passwordError.textContent="Password must be more than 5 letters"
        return false
      }
      else{
          passwordError.textContent=""
          return true 
      }
    }
    
    
    function validateEmail(){
      var email=document.getElementById('email').value;
      var emailError=document.getElementById('emailError')
      const match= /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    
      if(email===""){
          emailError.textContent="Email is required"
          return false
      }else if(!match.test(email)){
          emailError.textContent="Email is invalid"
          return false
      }
      else{
          emailError.textContent=""
          return true 
      }
    }
    
    
    function matchPass(){
        const password=document.getElementById('pass').value;
        const cpassword=document.getElementById('re_pass').value;
        const cpasswordError=document.getElementById('cpassError')

if(password !== cpassword){
cpasswordError.textContent="password not match confirm"
return false
}else{
    cpasswordError.textContent=''
    return true
}
    }
    
    function enableSubmit(){
        const nameValid=validateName()
        const passwordValid=validatePassword()
        const emailValid=validateEmail()
        const matchPassword=matchPass()
        // const department=validateDepartment()
        // const role=validateRole()
      const submitButton=document.getElementById('signup')
      if(nameValid && passwordValid && emailValid && matchPassword ){
        submitButton.disabled=false;
    } else {
        submitButton.disabled=true;
    }
    }
    
    
    $('#name , #pass , #email,#re_pass').on('keyup',function(){
        enableSubmit()
    })
    
    
    })
    
    
    
    document.getElementById('signup').on('click',function(event){
        event.preventDefault()
        var FormData={
            name: document.getElementById('name').value,
            password: document.getElementById('password').value,
            email: document.getElementById('email').value
        }

        
        })
    