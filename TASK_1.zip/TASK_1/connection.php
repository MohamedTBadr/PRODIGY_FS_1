<?php
$localhost='localhost';
$password='';
$username='root';
$dbname='Prodigy_Auth';

$connect=mysqli_connect($localhost,$username,$password,$dbname);
session_start();

?>