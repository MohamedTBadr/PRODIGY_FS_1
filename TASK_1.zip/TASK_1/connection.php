<?php
$localhost='localhost';
$password='';
$username='root';
$dbname='Prodigy_Auth';

$connect=mysqli_connect($localhost,$username,$password,$dbname);
session_start();
if(isset($_POST['logout'])){
    session_unset();
    session_destroy();
    header("location:index.php");
  }

?>