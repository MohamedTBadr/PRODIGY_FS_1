<?php
include 'mail.php';
$name=$_SESSION['name'];
 $email=$_SESSION['email'];
 $time1=$_SESSION['time'];
 $message='';
 if(isset($_GET['fr'])){

    if(isset($_POST['submit'])){
        $time2=time();
    $otp=$_SESSION['otp'];
        $otpUser=$_POST['otp1']."".$_POST['otp2']."".$_POST['otp3']."".$_POST['otp4'];
        if($otp==$otpUser){
            if($time2-$time1<180){
                $message= 'correct OTP';

    header("Refresh: 3; url=changePass.php");
            }else{
            $message= 'expired OTP';
        }
        }
        else{
            $message= 'incorrect OTP';
        }
    }
        //resend
        if(isset($_GET['resend'])){
        unset($_SESSION['time']);
        unset($_SESSION['otp']);
        $otp=rand(1000,9999);
        $_SESSION['otp']=$otp;
        $time=time();
        $_SESSION['time']=$time;
        $massage = "
        <body style='font-family: Arial, sans-serif; margin: 0; padding: 0; background-color: #fffffa ; color: #00000a ;'>
            <div style='background-color: #0a7273 ; padding: 20px ; text-align: center ; color: #fffffa ;'>
                <h1>Password Reset Request</h1>
            </div>
            <div style='padding: 20px ; background-color: #fffffa ; color: #00000a ;'>
                <p style='color: #00000a ;'>Dear <span style='color: #fda521;'>$name</span>,</p>
                <p style='color: #00000a ;'>Please use the OTP below to complete the process:</p>
                <p style='color: #00000a ; text-align: center ; font-size: 24px ; font-weight: bold ; color: #fda521 ;'>$otp</p>
                <p style='color: #00000a ;'>if any problem happen please contact our support team for assistance.</p>
                <p style='color: #00000a ;'>Best regards,<br>The Organizo Team</p>
            </div>
            <div style='background-color: #0a7273; padding: 10px; text-align: center; color: #fffffa;'>
                <p style='color: #fffffa;'>For support and updates, please visit our website or contact us via email.</p>
                <p style='color: #fffffa;'>Email: <a href='mailto:organizohelp@gmail.com' style='color: #fda521;'>organizohelp@gmail.com</a></p>
            </div>
        </body>
    
    ";
    
    
    
    $mail->setFrom('organizohelp@gmail.com', 'Organizo');
    $mail->addAddress($email);
    $mail->isHTML(true);
    $mail->Subject = 'Reset password';
    $mail->Body = $massage;
    $mail->send();
        }
 }else{
    if(isset($_POST['submit'])){
    $time2=time();
$otp=$_SESSION['otp'];
    $otpUser=$_POST['otp1']."".$_POST['otp2']."".$_POST['otp3']."".$_POST['otp4'];
    if($otp==$otpUser){
        if($time2-$time1<180){
 $hashedPass=password_hash($password,PASSWORD_DEFAULT);

$insert="INSERT INTO `user` values(null,'$name','$email','$hashedPass')";
$runInsert=mysqli_query($connect,$insert);
if($runInsert){
    unset($_SESSION["otp"]);
    unset($_SESSION["time"]);
    unset($_SESSION["name"]);
    unset($_SESSION["email"]);
    unset($_SESSION["password"]);
    $message= 'account has been verify successfully';
    header("Refresh: 5; url=login.php");

    }
    }else{
        $message= 'expired OTP';
    }
    }
    else{
        $message= 'incorrect OTP';
    }
}
    //resend
    if(isset($_GET['resend'])){
    unset($_SESSION['time']);
    unset($_SESSION['otp']);
    $otp=rand(1000,9999);
    $_SESSION['otp']=$otp;
    $time=time();
    $_SESSION['time']=$time;
    $massage = "
    <body style='font-family: Arial, sans-serif; margin: 0; padding: 0; background-color: #fffffa ; color: #00000a ;'>
        <div style='background-color: #0a7273 ; padding: 20px ; text-align: center ; color: #fffffa ;'>
            <h1>Password Reset Request</h1>
        </div>
        <div style='padding: 20px ; background-color: #fffffa ; color: #00000a ;'>
            <p style='color: #00000a ;'>Dear <span style='color: #fda521;'>$name</span>,</p>
            <p style='color: #00000a ;'>Please use the OTP below to complete the process:</p>
            <p style='color: #00000a ; text-align: center ; font-size: 24px ; font-weight: bold ; color: #fda521 ;'>$otp</p>
            <p style='color: #00000a ;'>if any problem happen please contact our support team for assistance.</p>
            <p style='color: #00000a ;'>Best regards,<br>The Organizo Team</p>
        </div>
        <div style='background-color: #0a7273; padding: 10px; text-align: center; color: #fffffa;'>
            <p style='color: #fffffa;'>For support and updates, please visit our website or contact us via email.</p>
            <p style='color: #fffffa;'>Email: <a href='mailto:organizohelp@gmail.com' style='color: #fda521;'>organizohelp@gmail.com</a></p>
        </div>
    </body>

";



$mail->setFrom('organizohelp@gmail.com', 'Organizo');
$mail->addAddress($email);
$mail->isHTML(true);
$mail->Subject = 'Reset Password';
$mail->Body = $massage;
$mail->send();


}}
?>

<!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>OTP Verification</title>
      <link rel="stylesheet" href="css/otp.css">
      <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

     
  </head>
  <body>

      <div class="container">
        <form method="POST">
          <h1>OTP Verification</h1>
          <p>Enter the 4-digit code sent to your device</p>
          <?php if(isset($message)){?>
        <p><?php echo $message ?></p>
            <?php } ?>
          <div id="timer">Time remaining: 3:00</div>
          <div class="otp-input">
              <input type="number" name="otp1" min="0" max="9"  required>
              <input type="number"name="otp2" min="0" max="9" required>
              <input type="number"name="otp3" min="0" max="9" required>
              <input type="number"name="otp4" min="0" max="9" required>

          </div>
          <button type="submit" name="submit">Verify</button>
          <a href="otp.php?<?php if(isset($_GET['fr'])){echo "fr= &&";}else{echo '';}?>resend=" id="resendButton">Resend Code</a>
          </form>
      </div>
      <script src="js/otp.js"></script>
  </body>
  </html>