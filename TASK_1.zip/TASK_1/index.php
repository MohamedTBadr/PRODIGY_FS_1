<?php
include 'connection.php';


?>

<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>Hirevac</title>


  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:400,600,700&display=swap" rel="stylesheet">

  <!-- font awesome style -->
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <!-- nice select -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/css/nice-select.min.css" integrity="sha256-mLBIhmBvigTFWPSCtvdu6a76T+3Xyt+K571hupeFLg4=" crossorigin="anonymous" />

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />

</head>

<body>

  <div class="hero_area">
    <!-- header section strats -->
    <header class="header_section">
      <div class="container-fluid">
        <nav class="navbar navbar-expand-lg custom_nav-container ">
          <a class="navbar-brand" href="index.html">
            <span>
              Mohamed Tarek
            </span>
          </a>

          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class=""> </span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav  ml-auto">
              <li class="nav-item active">
                <a class="nav-link" href="index.html">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="about.html"> About</a>
              </li>
              <?php if(isset($_SESSION['user_id'])){?>
              <li class="nav-item">
                
                <a class="nav-link" href="job.html">Jobs</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="freelancer.html">Freelancers</a>
              </li>
              <?php }else{ ?>
              <li class="nav-item">
                <a class="nav-link" href="login.php">
                  <i class="fa fa-user" aria-hidden="true"></i>
                  <span>
                    Login
                  </span>
                </a>
              </li>
              <?php } ?>
              <!-- <li class="nav-item">
                <a class="nav-link" href="#">
                  <i class="fa fa-user" aria-hidden="true"></i>
                  <span>
                    Sign Up
                  </span>
                </a>
              </li> -->
              <form class="form-inline">
                <button class="btn   nav_search-btn" type="submit">
                  <i class="fa fa-search" aria-hidden="true"></i>
                </button>
              </form>
            </ul>
          </div>
        </nav>
      </div>
    </header>
    <!-- end header section -->
    <!-- slider section -->
    <section class="slider_section ">
      <div class="container ">
        <div class="row">
          <div class="col-lg-7 col-md-8 mx-auto">
            <div class="detail-box">
              <h1>
                Build Your <br>
                POWERFUL CAREER
              </h1>
              <p>
                when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal
                distribution of letters, as opposed to
              </p>
            </div>
          </div>
        </div>
        <div class="find_container ">
          <div class="container">
            <div class="row">
              <div class="col">
                <form>
                  <div class="form-row ">
                    <div class="form-group col-lg-3">
                      <input type="text" class="form-control" id="inputPatientName" placeholder="Keywords">
                    </div>
                    <div class="form-group col-lg-3">
                      <select name="" class="form-control wide" id="inputDoctorName">
                        <option value="Normal distribution ">All Locations</option>
                        <option value="Normal distribution ">Location 2 </option>
                        <option value="Normal distribution ">Location 3 </option>
                      </select>
                    </div>
                    <div class="form-group col-lg-3">
                      <select name="" class="form-control wide" id="inputDepartmentName">
                        <option value="Normal distribution ">SEO Expert </option>
                        <option value="Normal distribution ">Web Designer </option>
                        <option value="Normal distribution ">Web Developer</option>
                        <option value="Normal distribution ">Graphic Deesigner</option>
                        <option value="Normal distribution ">Content Writer</option>
                      </select>
                    </div>
                    <div class="form-group col-lg-3">
                      <div class="btn-box">
                        <button type="submit" class="btn ">Submit Now</button>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
            <ul class="job_check_list">
              <li class=" ">
                <input id="checkbox_qu_01" type="checkbox" class="styled-checkbox">
                <label for="checkbox_qu_01">
                  Freelancer
                </label>
              </li>
              <li class=" ">
                <input id="checkbox_qu_02" type="checkbox" class="styled-checkbox">
                <label for="checkbox_qu_02">
                  Part Time
                </label>
              </li>
              <li class=" ">
                <input id="checkbox_qu_03" type="checkbox" class="styled-checkbox">
                <label for="checkbox_qu_03">
                  Full Time
                </label>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
    <!-- end slider section -->
  </div>
  <!-- category section -->
  <section class="category_section">
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-6 col-md-4 col-xl-2 px-0">
          <a href="#" class="box">
            <div class="img-box">
              <img src="images/c1.png" alt="">
            </div>
            <div class="detail-box">
              <h5>
                Web Design
              </h5>
            </div>
          </a>
        </div>
        <div class="col-sm-6 col-md-4 col-xl-2 px-0">
          <a href="#" class="box">
            <div class="img-box">
              <img src="images/c2.png" alt="">
            </div>
            <div class="detail-box">
              <h5>
                Web Development
              </h5>
            </div>
          </a>
        </div>
        <div class="col-sm-6 col-md-4 col-xl-2 px-0">
          <a href="#" class="box">
            <div class="img-box">
              <img src="images/c3.png" alt="">
            </div>
            <div class="detail-box">
              <h5>
                Graphic Design
              </h5>
            </div>
          </a>
        </div>
        <div class="col-sm-6 col-md-4 col-xl-2 px-0">
          <a href="#" class="box">
            <div class="img-box">
              <img src="images/c4.png" alt="">
            </div>
            <div class="detail-box">
              <h5>
                Seo marketing
              </h5>
            </div>
          </a>
        </div>
        <div class="col-sm-6 col-md-4 col-xl-2 px-0">
          <a href="#" class="box">
            <div class="img-box">
              <img src="images/c5.png" alt="">
            </div>
            <div class="detail-box">
              <h5>
                Accounting
              </h5>
            </div>
          </a>
        </div>
        <div class="col-sm-6 col-md-4 col-xl-2 px-0">
          <a href="#" class="box">
            <div class="img-box">
              <img src="images/c6.png" alt="">
            </div>
            <div class="detail-box">
              <h5>
                Content Writing
              </h5>
            </div>
          </a>
        </div>
      </div>
    </div>
  </section>
  <!-- end category section -->


  <!-- about section -->

  <section class="about_section layout_padding">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <div class="detail-box">
            <div class="heading_container">
              <h2>
                About Us
              </h2>
            </div>
            <p>
              Normal distribution of letters, as opposed to using 'Content here, content here', making it look like
              readable English. Many desktop publishing packages and web page editors has a more-or-less normal
              distribution of letters, as opposed to using 'Content here, content here', making it look like readable
              English. Many desktop publishing packages and web page editors
            </p>
            <a href="">
              Read More
            </a>
          </div>
        </div>
        <div class="col-md-6">
          <div class="img-box">
            <img src="images/about-img.jpg" alt="">
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end about section -->

  <!-- job section -->
  <section class="job_section layout_padding">
    <div class="container">
      <div class="heading_container heading_center">
        <h2>
          RECENT & FEATURED JOBS
        </h2>
      </div>
      <div class="job_container">
        <h4 class="job_heading">
          Featured Jobs
        </h4>
        <div class="row">
          <div class="col-lg-6">
            <div class="box">
              <div class="job_content-box">
                <div class="img-box">
                  <img src="images/job_logo1.png" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    Development Team Lead
                  </h5>
                  <div class="detail-info">
                    <h6>
                      <i class="fa fa-map-marker" aria-hidden="true"></i>
                      <span>
                        Washington. D.C.
                      </span>
                    </h6>
                    <h6>
                      <i class="fa fa-money" aria-hidden="true"></i>
                      <span>
                        $1200 - $1300
                      </span>
                    </h6>
                  </div>
                </div>
              </div>
              <div class="option-box">
                <button class="fav-btn">
                  <i class="fa fa-heart-o" aria-hidden="true"></i>
                </button>
                <a href="" class="apply-btn">
                  Apply Now
                </a>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="box">
              <div class="job_content-box">
                <div class="img-box">
                  <img src="images/job_logo2.png" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    Make my website responsive device compatible
                  </h5>
                  <div class="detail-info">
                    <h6>
                      <i class="fa fa-map-marker" aria-hidden="true"></i>
                      <span>
                        New York
                      </span>
                    </h6>
                    <h6>
                      <i class="fa fa-money" aria-hidden="true"></i>
                      <span>
                        $200 - $340
                      </span>
                    </h6>
                  </div>
                </div>
              </div>
              <div class="option-box">
                <button class="fav-btn">
                  <i class="fa fa-heart-o" aria-hidden="true"></i>
                </button>
                <a href="" class="apply-btn">
                  Apply Now
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="job_container">
        <h4 class="job_heading">
          Recent Jobs
        </h4>
        <div class="row">
          <div class="col-lg-6">
            <div class="box">
              <div class="job_content-box">
                <div class="img-box">
                  <img src="images/job_logo3.png" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    Looking Graphic Designer (Logo + UI)
                  </h5>
                  <div class="detail-info">
                    <h6>
                      <i class="fa fa-map-marker" aria-hidden="true"></i>
                      <span>
                        Washington. D.C.
                      </span>
                    </h6>
                    <h6>
                      <i class="fa fa-money" aria-hidden="true"></i>
                      <span>
                        $1200/mo
                      </span>
                    </h6>
                  </div>
                </div>
              </div>
              <div class="option-box">
                <button class="fav-btn">
                  <i class="fa fa-heart-o" aria-hidden="true"></i>
                </button>
                <a href="" class="apply-btn">
                  Apply Now
                </a>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="box">
              <div class="job_content-box">
                <div class="img-box">
                  <img src="images/job_logo6.png" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    Are you Typography Expert?
                  </h5>
                  <div class="detail-info">
                    <h6>
                      <i class="fa fa-map-marker" aria-hidden="true"></i>
                      <span>
                        New York
                      </span>
                    </h6>
                    <h6>
                      <i class="fa fa-money" aria-hidden="true"></i>
                      <span>
                        $56 - $90
                      </span>
                    </h6>
                  </div>
                </div>
              </div>
              <div class="option-box">
                <button class="fav-btn">
                  <i class="fa fa-heart-o" aria-hidden="true"></i>
                </button>
                <a href="" class="apply-btn">
                  Apply Now
                </a>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="box">
              <div class="job_content-box">
                <div class="img-box">
                  <img src="images/job_logo5.png" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    Looking WordPress Developer for ThemeForest
                  </h5>
                  <div class="detail-info">
                    <h6>
                      <i class="fa fa-map-marker" aria-hidden="true"></i>
                      <span>
                        Washington. D.C.
                      </span>
                    </h6>
                    <h6>
                      <i class="fa fa-money" aria-hidden="true"></i>
                      <span>
                        $400 - $540
                      </span>
                    </h6>
                  </div>
                </div>
              </div>
              <div class="option-box">
                <button class="fav-btn">
                  <i class="fa fa-heart-o" aria-hidden="true"></i>
                </button>
                <a href="" class="apply-btn">
                  Apply Now
                </a>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="box">
              <div class="job_content-box">
                <div class="img-box">
                  <img src="images/job_logo4.png" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    Hiring Web Designer for Project
                  </h5>
                  <div class="detail-info">
                    <h6>
                      <i class="fa fa-map-marker" aria-hidden="true"></i>
                      <span>
                        Washington. D.C.
                      </span>
                    </h6>
                    <h6>
                      <i class="fa fa-money" aria-hidden="true"></i>
                      <span>
                        $350 - $450
                      </span>
                    </h6>
                  </div>
                </div>
              </div>
              <div class="option-box">
                <button class="fav-btn">
                  <i class="fa fa-heart-o" aria-hidden="true"></i>
                </button>
                <a href="" class="apply-btn">
                  Apply Now
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="btn-box">
        <a href="">
          View All
        </a>
      </div>
    </div>
  </section>
  <!-- end job section -->

  <!-- expert section -->

  <section class="expert_section layout_padding">
    <div class="container">
      <div class="heading_container heading_center">
        <h2>
          LOOKING FOR EXPERTS?
        </h2>
        <p>
          Lorem ipsum dolor sit amet, non odio tincidunt ut ante, lorem a euismod suspendisse vel, sed quam nulla mauris
          iaculis. Erat eget vitae malesuada, tortor tincidunt porta lorem lectus.
        </p>
      </div>
      <div class="row">
        <div class="col-md-6 col-lg-4 mx-auto">
          <div class="box">
            <div class="img-box">
              <img src="images/e1.jpg" alt="">
            </div>
            <div class="detail-box">
              <a href="">
                Martin Anderson
              </a>
              <h6 class="expert_position">
                <span>
                  Web Anaylzer
                </span>
                <span>
                  41 Jobs Done
                </span>
              </h6>
              <span class="expert_rating">
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
              </span>
              <p>
                Lorem ipsum dolor sit amet, non odio tincidunt ut ante, lorem a euismod suspendisse vel, sed quam
                nulla
                mauris iaculis.
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4 mx-auto">
          <div class="box">
            <div class="img-box">
              <img src="images/e2.jpg" alt="">
            </div>
            <div class="detail-box">
              <a href="">
                Semanta Klores
              </a>
              <h6 class="expert_position">
                <span>
                  Graphic Designer
                </span>
                <span>
                  32 Jobs Done
                </span>
              </h6>
              <span class="expert_rating">
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
              </span>
              <p>
                Lorem ipsum dolor sit amet, non odio tincidunt ut ante, lorem a euismod suspendisse vel, sed quam
                nulla
                mauris iaculis.
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4 mx-auto">
          <div class="box">
            <div class="img-box">
              <img src="images/e3.jpg" alt="">
            </div>
            <div class="detail-box">
              <a href="">
                Ryan Martines
              </a>
              <h6 class="expert_position">
                <span>
                  SEO Expert
                </span>
                <span>
                  27 Jobs Done
                </span>
              </h6>
              <span class="expert_rating">
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
              </span>
              <p>
                Lorem ipsum dolor sit amet, non odio tincidunt ut ante, lorem a euismod suspendisse vel, sed quam
                nulla
                mauris iaculis.
              </p>
            </div>
          </div>
        </div>
      </div>
      <div class="btn-box">
        <a href="">
          View All Freelancers
        </a>
      </div>
    </div>
  </section>

  <!-- end expert section -->

  <!-- info section -->
  <section class="info_section ">
    <div class="container">
      <div class="row">
        <div class="col-md-2 info_links">
          <h4>
            Menu
          </h4>
          <ul>
            <li class="active">
              <a href="index.html">
                Home
              </a>
            </li>
            <li>
              <a href="about.html">
                About
              </a>
            </li>
            <li>
              <a class="" href="job.html">
                Jobs
              </a>
            </li>
            <li>
              <a class="" href="freelancer.html">
                Freelancers
              </a>
            </li>
          </ul>
        </div>
        <div class="col-md-3">
          <h4>
            Jobs
          </h4>
          <p>
            Established fact that a reader will be distracted by the readable content of a page when looking at its
            layout. The point of using Lorem Ipsum
          </p>
        </div>
        <div class="col-md-3">
          <div class="info_social">
            <h4>
              Social Link
            </h4>
            <div class="social_container">
              <div>
                <a href="">
                  <i class="fa fa-facebook" aria-hidden="true"></i>
                </a>
              </div>
              <div>
                <a href="">
                  <i class="fa fa-twitter" aria-hidden="true"></i>
                </a>
              </div>
              <div>
                <a href="">
                  <i class="fa fa-linkedin" aria-hidden="true"></i>
                </a>
              </div>
              <div>
                <a href="">
                  <i class="fa fa-instagram" aria-hidden="true"></i>
                </a>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="info_form">
            <h4>
              Newsletter
            </h4>
            <form action="">
              <input type="text" placeholder="Enter Your Email" />
              <button type="submit">
                Subscribe
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- end info_section -->


  <!-- footer section -->
  <footer class="footer_section">
    <div class="container">
      <p>
        &copy; <span id="displayYear"></span> All Rights Reserved By
        <a href="https://html.design/">Free Html Templates</a>
      </p>
    </div>
  </footer>
  <!-- footer section -->

  <!-- jQery -->
  <script src="js/jquery-3.4.1.min.js"></script>
  <!-- bootstrap js -->
  <script src="js/bootstrap.js"></script>
  <!-- nice select -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/js/jquery.nice-select.min.js" integrity="sha256-Zr3vByTlMGQhvMfgkQ5BtWRSKBGa2QlspKYJnkjZTmo=" crossorigin="anonymous"></script>
  <!-- custom js -->
  <script src="js/custom.js"></script>


</body>

</html>