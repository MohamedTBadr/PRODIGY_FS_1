
<?php
include 'mail.php';
if(isset( $_POST['signup'])){
$message='';

    $name=mysqli_real_escape_string($connect,$_POST['name']);
    $email=mysqli_real_escape_string($connect,$_POST['email']);
    $password=mysqli_real_escape_string($connect,$_POST['pass']);
    $cpassword=mysqli_real_escape_string($connect,$_POST['re_pass']);
    $pattern = '/[A-Z]/';  // Check for uppercase
    $pattern2 = '/[0-9]/';  // Check for number
    $pattern3 = '/[\W_]/';  // Check for special character
    $select="SELECT `email` from user where email='$email'";
    $runSelect=mysqli_query($connect,$select);
    if(mysqli_num_rows($runSelect)>0){
        $message='account is already taken';
    }elseif(empty($name)){
        $message="name can't be empty";
    }elseif(!filter_var($email,FILTER_VALIDATE_EMAIL)){
        $message="email format is wrong";
    }elseif(empty($password)){
        $message="password can't be empty";
    }elseif(empty($cpassword)){
        $message="name can't be empty";
    }elseif($password!==$cpassword){
$message='password not matched confirm';
    }elseif(!preg_match($pattern,$password) && !preg_match($pattern2,$password) && !preg_match($pattern3,$password)){
$message='password should contain at least 1 special character, 1 number,1 upper case';
    }elseif(strlen($password)<5){
$message='password should be more than 5 letter';
    }else{
    $otp=rand(1000,9999);
    $time=time();
    $massageMail = "
    <body style='font-family: Arial, sans-serif; margin: 0; padding: 0; background-color: #fffffa ; color: #00000a ;'>
        <div style='background-color: #0a7273 ; padding: 20px ; text-align: center ; color: #fffffa ;'>
            <h1>Password Reset Request</h1>
        </div>
        <div style='padding: 20px ; background-color: #fffffa ; color: #00000a ;'>
            <p style='color: #00000a ;'>Dear <span style='color: #fda521;'>$name</span>,</p>
            <p style='color: #00000a ;'>Please use the OTP below to complete the process:</p>
            <p style='color: #00000a ; text-align: center ; font-size: 24px ; font-weight: bold ; color: #fda521 ;'>$otp</p>
            <p style='color: #00000a ;'>if any problem happen please contact our support team for assistance.</p>
            <p style='color: #00000a ;'>Best regards,<br>The Organizo Team</p>
        </div>
        <div style='background-color: #0a7273; padding: 10px; text-align: center; color: #fffffa;'>
            <p style='color: #fffffa;'>For support and updates, please visit our website or contact us via email.</p>
            <p style='color: #fffffa;'>Email: <a href='mailto:organizohelp@gmail.com' style='color: #fda521;'>organizohelp@gmail.com</a></p>
        </div>
    </body>

";



$mail->setFrom('organizohelp@gmail.com', 'Organizo');
$mail->addAddress($email);
$mail->isHTML(true);
$mail->Subject = 'OTP Code';
$mail->Body = ($massageMail);
$mail->send();

$_SESSION['otp'] = $otp;
$_SESSION['time']=$time;
$_SESSION['name']=$name;
$_SESSION['email']=$email;
$_SESSION['password']=$password;

header("location:otp.php");
}
}


?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sign-up</title>
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Main css -->
<link rel="stylesheet" href="css/style1.css">

</head>

<body>
    <div class="main">
        <!-- Sign up form -->
        <section class="signup">
            <div class="container">
                <div class="signup-content">
                    <div class="signup-form">
                        <h2 class="form-title">Sign up</h2>
                        <?php if(isset($message)){?>
                        
                            <p class="err"><?php echo $message ?></p>
                        
                        <?php } ?>

                        <form method="POST" class="register-form" id="register-form" oninput="enableSubmit()">
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="name" id="name" placeholder="Your Name" value="<?php echo isset($_POST['name']) ? $_POST['name'] : ''; ?>" oninput="validateName()"/>
                            </div>
                            <p id="nameError" class="err"></p>
                            <div class="form-group">
                                <label for="email"><i class="zmdi zmdi-email"></i></label>
                                <input type="email" name="email" id="email" placeholder="Your Email" value="<?php echo isset($_POST['email']) ? $_POST['email'] : ''; ?>" oninput="validateEmail()"/>
                            </div>
                            <p id="emailError" class="err"></p>

                            <div class="form-group">
                                <label for="pass"><i class="zmdi zmdi-lock"></i></label>
                                <input type="password" name="pass" id="pass" placeholder="Password"  value="<?php echo isset($_POST['pass']) ? $_POST['pass'] : ''; ?>"oninput="validatePassword()"/>
                                
                            </div>
                            <p id="passwordError" class="err"></p>
                            <div class="form-group">
                                <label for="re-pass"><i class="zmdi zmdi-lock-outline"></i></label>
                                <input type="password" name="re_pass" id="re_pass" value="<?php echo isset($_POST['re_pass']) ? $_POST['re_pass'] : ''; ?>" placeholder="Repeat your password" oninput="matchPass()"/>
                                
                            </div>
                            <p id="cpassError" class="err"></p>
                            <div class="form-group">
                                <input type="checkbox" name="agree-term" id="agree-term" class="agree-term" />
                                <label for="agree-term" class="label-agree-term"><span><span></span></span>I agree all statements in  <a href="#" class="term-service">Terms of service</a></label>
                            </div>
                            <div class="form-group form-button">
                                <button type="submit" name="signup" id="signup" class="form-submit" disabled>Register</button>
                            </div>
                        </form>
                    </div>
                    <div class="signup-image">
                        <figure><img src="images/signup-image.jpg" alt="sing up image"></figure>
                        <a href="login.php" class="signup-image-link">I am already member</a>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <script src="js/validations.js"></script>
<!-- <script src="vendor/jquery/jquery.min.js"></script> -->
    <script src="js/main.js"></script>
</body>
</html>