<?php
include 'mail.php';
$message='';
if(isset($_POST['submit'])){
    $email=$_SESSION['email'];
    $password=mysqli_real_escape_string($connect,$_POST['pass']);
    $cPassword=mysqli_real_escape_string($connect,$_POST['re_pass']);
if($password!==$cPassword){
    $message="<p class='err'>password doesn't match confirm one</p>";
}else{
    $hashedPass=password_hash($password,PASSWORD_DEFAULT);

    $update="UPDATE user set password ='$hashedPass' where email='$email'";
    $runUpdate=mysqli_query($connect,$update);
    $message='<p class="success">password has changed successfully</p>';
unset($_SESSION['name']);
unset($_SESSION['email']);
unset($_SESSION['otp']);
unset($_SESSION['time']);
    header("Refresh: 1 ; url=login.php");
}
}


?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Main css -->
<link rel="stylesheet" href="css/style1.css">

</head>

<body>
    <div class="main">
        <!-- Sign up form -->
        <section class="signup">
            <div class="container">
                <div class="signup-content">
                    <div class="signup-form">
                        <h2 class="form-title">Change Password</h2>
                        <?php if(isset($message)){?>
                        
                            <?php echo $message ?>
                        
                        <?php } ?>

                        <form method="POST" class="register-form" id="register-form" oninput="enableSubmit()">
                            <div class="form-group">
                                <label for="pass"><i class="zmdi zmdi-lock"></i></label>
                                <input type="password" name="pass" id="pass" placeholder="Password"  value="<?php echo isset($_POST['pass']) ? $_POST['pass'] : ''; ?>"oninput="validatePassword()"/>
                                
                            </div>
                            <p id="passwordError" class="err"></p>
                            <div class="form-group">
                                <label for="re-pass"><i class="zmdi zmdi-lock-outline"></i></label>
                                <input type="password" name="re_pass" id="re_pass" value="<?php echo isset($_POST['re_pass']) ? $_POST['re_pass'] : ''; ?>" placeholder="Repeat your password" oninput="matchPass()"/>
                                
                            </div>
                            <p id="cpassError" class="err"></p>
                            
                            <div class="form-group form-button">
                                <button type="submit" name="submit" id="signup" class="form-submit" disabled>change Pass</button>
                            </div>
                        </form>
                    </div>
                    <div class="signup-image">
                        <figure><img src="images/signup-image.jpg" alt="sing up image"></figure>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <script src="js/changePass.js"></script>
<!-- <script src="vendor/jquery/jquery.min.js"></script> -->
    <script src="js/main.js"></script>
</body>
</html>