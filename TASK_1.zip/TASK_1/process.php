<?php
include 'mail.php';
if($_SERVER['REQUEST_METHOD']== 'POST'){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $otp=rand(1000,9999);
    $time=time();
    $massage = "
    <body style='font-family: Arial, sans-serif; margin: 0; padding: 0; background-color: #fffffa ; color: #00000a ;'>
        <div style='background-color: #0a7273 ; padding: 20px ; text-align: center ; color: #fffffa ;'>
            <h1>Password Reset Request</h1>
        </div>
        <div style='padding: 20px ; background-color: #fffffa ; color: #00000a ;'>
            <p style='color: #00000a ;'>Dear <span style='color: #fda521;'>$last_name</span>,</p>
            <p style='color: #00000a ;'>Please use the OTP below to complete the process:</p>
            <p style='color: #00000a ; text-align: center ; font-size: 24px ; font-weight: bold ; color: #fda521 ;'>$otp</p>
            <p style='color: #00000a ;'>if any problem happen please contact our support team for assistance.</p>
            <p style='color: #00000a ;'>Best regards,<br>The Organizo Team</p>
        </div>
        <div style='background-color: #0a7273; padding: 10px; text-align: center; color: #fffffa;'>
            <p style='color: #fffffa;'>For support and updates, please visit our website or contact us via email.</p>
            <p style='color: #fffffa;'>Email: <a href='mailto:organizohelp@gmail.com' style='color: #fda521;'>organizohelp@gmail.com</a></p>
        </div>
    </body>

";
$_SESSION["otp"] = $otp;
$_SESSION['time']=$time;
$_SESSION['name']=$name;
$_SESSION['email']=$email;
$_SESSION['password']=$password;



$mail->setFrom('organizohelp@gmail.com', 'Organizo');
$mail->addAddress($email);
$mail->isHTML(true);
$mail->Subject = 'Password Reset OTP';
$mail->Body = ($massage);
$mail->send();

header("location:otp.php");
}



?>




